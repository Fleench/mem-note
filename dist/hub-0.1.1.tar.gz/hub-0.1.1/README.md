# hub — plugin-based note & utility runner 🔧

**hub** is a small, plugin-driven CLI for simple note management and other utilities. It ships with example plugins and a plugin loader that copies packaged plugins into a user config folder and runs plugin commands.

## Features

- Lightweight plugin system (plugins are plain Python files) ✅
- Local per-project data init (`hub init`) and global data directory support (`hub load`) 📁
- Plugin metadata discovery and command dispatching ⚙️

## Quick install

- From source (editable):

```sh
pip install -e .
```

- Or run directly:

```sh
python -m hub.main <command>
```

(Note: the project has a console script in `pyproject.toml`—the CLI is `hub`.)

## Usage examples

- Initialize a local data directory:

```sh
hub init
```

- Set a custom data directory:

```sh
hub load /path/to/data
```

- Run a plugin command (format: <plugin>.<command>):

```sh
hub notes.new shopping "Milk and bread"
hub notes.list
hub info        # list available plugins
hub info notes  # show metadata for 'notes'
```

## Plugin conventions 🔌

- Plugins are Python files placed in the config directory (automatically copied from `src/hub/plugins/`).
- Export functions named after commands. Each command function signature:

```py
def command(data_dir, local_data_dir, config_dir, args): ...
```

- Optionally provide metadata:

```py
def meta_data():
    return {"name": "notes", "description": "Manage notes", "file_path": __file__}
```

- Use the `info` plugin to view available plugins and metadata.

## Configuration and data locations

- Config dir (Linux/macOS): `$XDG_CONFIG_HOME/hub` (or `~/.config/hub`)
- Data dir (fallback): `$XDG_DATA_HOME/hub` (or `~/.local/share/hub`)
- Local project data: `./.mem` if `hub init` is run in a folder

## Development notes 🔧

- Code entrypoint: `src/hub/main.py`
- Plugins live under: `src/hub/plugins/`
- Run locally:

```sh
PYTHONPATH=src python -m hub.main <command>
```

- Confirmed preferred CLI: **hub** (was `mem-note` in older metadata)

## Contributing

- Open issues/PRs for fixes or plugin additions
- Keep plugin APIs simple and stateless (file-based storage preferred)

## License

This project is licensed under the terms in `LICENSE`.
