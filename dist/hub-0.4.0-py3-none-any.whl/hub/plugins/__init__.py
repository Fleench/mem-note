"""Plugin package for mem-note."""
